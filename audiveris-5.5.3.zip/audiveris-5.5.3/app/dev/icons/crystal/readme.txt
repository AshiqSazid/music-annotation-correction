+++++++++++++++++ 
This copyright and license notice covers the images in this directory +++++++++++++++++
************************************************************************



TITLE:	Crystal Project Icons

AUTHOR:	Everaldo Coelho

SITE:	http://www.everaldo.com

CONTACT: everaldo@everaldo.com

LICENSE: LGPL


Staff:


Ingolfur Haraldsson (ingo@linpire.com)

Luiz Claudio dos Santos (luiz@yellowicon.com)

Rhandros Dembicki (rhandros@yellowicon.com)

Paulo andre (paulo@yellowicon.com)

Edson Farias (edson@yellowicon.com)

Andre Souza (andre@yellowicon.com)

