/**
 * Package for imaging performed with JAI software (Java Advanced Imaging).
 */
package org.audiveris.omr.image.jai;
