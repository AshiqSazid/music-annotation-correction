/**
 * Package for runs (vertical or horizontal sequences of foreground pixels).
 */
package org.audiveris.omr.run;
