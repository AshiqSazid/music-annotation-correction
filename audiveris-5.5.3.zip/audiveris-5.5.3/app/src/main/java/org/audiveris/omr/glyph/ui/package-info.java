/**
 * Package dedicated to all user interfaces that deal with glyphs.
 */
package org.audiveris.omr.glyph.ui;
