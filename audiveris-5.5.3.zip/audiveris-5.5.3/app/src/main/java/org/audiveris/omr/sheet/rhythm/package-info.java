/**
 * Package for handling rhythm data in every stack of measures.
 */
package org.audiveris.omr.sheet.rhythm;
