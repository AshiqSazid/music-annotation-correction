/**
 * Package for the extraction and use of glyph mathematics moments.
 * <p>
 * <img src="doc-files/moments.png" alt="Moments UML">
 */
package org.audiveris.omr.moments;
