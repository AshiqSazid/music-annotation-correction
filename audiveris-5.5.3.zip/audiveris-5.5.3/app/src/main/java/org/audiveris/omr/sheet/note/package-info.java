/**
 * Package for the processing of notes (heads and rests).
 */
package org.audiveris.omr.sheet.note;
