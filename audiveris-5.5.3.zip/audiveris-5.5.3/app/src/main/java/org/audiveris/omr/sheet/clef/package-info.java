/**
 * Package for the processing of Clefs.
 */
package org.audiveris.omr.sheet.clef;
