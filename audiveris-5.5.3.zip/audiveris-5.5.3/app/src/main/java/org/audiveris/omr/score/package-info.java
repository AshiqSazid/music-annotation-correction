/**
 * Package for logical representation of a score, ant its outputs (MusicXML, PDF).
 */
package org.audiveris.omr.score;
