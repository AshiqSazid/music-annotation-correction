/**
 * Package dedicated to the handling of lag related UI.
 */
package org.audiveris.omr.lag.ui;
