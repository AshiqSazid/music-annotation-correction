/**
 * Package for handling suites of checks applied on candidates.
 */
package org.audiveris.omr.check;
