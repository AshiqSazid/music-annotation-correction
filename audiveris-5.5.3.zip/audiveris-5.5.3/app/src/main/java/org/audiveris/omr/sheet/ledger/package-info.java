/**
 * Package for the processing of ledgers.
 */
package org.audiveris.omr.sheet.ledger;
