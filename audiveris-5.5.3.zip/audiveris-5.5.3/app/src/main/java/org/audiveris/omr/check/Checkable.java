//------------------------------------------------------------------------------------------------//
//                                                                                                //
//                                       C h e c k a b l e                                        //
//                                                                                                //
//------------------------------------------------------------------------------------------------//
// <editor-fold defaultstate="collapsed" desc="hdr">
//
//  Copyright © Audiveris 2025. All rights reserved.
//
//  This program is free software: you can redistribute it and/or modify it under the terms of the
//  GNU Affero General Public License as published by the Free Software Foundation, either version
//  3 of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
//  without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
//  See the GNU Affero General Public License for more details.
//
//  You should have received a copy of the GNU Affero General Public License along with this
//  program.  If not, see <http://www.gnu.org/licenses/>.
//------------------------------------------------------------------------------------------------//
// </editor-fold>
package org.audiveris.omr.check;

import org.audiveris.omr.util.Vip;

/**
 * Interface <code>Checkable</code> describes a class of objects that can
 * be checked, generally via a suite of individual checks.
 *
 * @author Hervé Bitteur
 */
public interface Checkable
        extends Vip
{
    //~ Methods ------------------------------------------------------------------------------------

    /**
     * Store the check failure directly into the checkable entity.
     *
     * @param failure the failure to be stored
     */
    void addFailure (Failure failure);
}
