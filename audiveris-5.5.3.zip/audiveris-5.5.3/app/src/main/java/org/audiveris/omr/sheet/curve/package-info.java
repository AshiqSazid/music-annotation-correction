/**
 * Package for the processing of curves (slurs, wedges and endings).
 */
package org.audiveris.omr.sheet.curve;
