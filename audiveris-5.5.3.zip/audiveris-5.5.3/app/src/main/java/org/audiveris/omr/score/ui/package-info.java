/**
 * Package that gathers all classes dealing with user interface of a score.
 */
package org.audiveris.omr.score.ui;
