/**
 * Package for handling glyphs, seen as assemblies of pixels.
 */
package org.audiveris.omr.glyph;
