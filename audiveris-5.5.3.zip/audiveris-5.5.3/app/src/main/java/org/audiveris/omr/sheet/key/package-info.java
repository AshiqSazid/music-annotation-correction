/**
 * Package for the processing of Key signatures.
 */
package org.audiveris.omr.sheet.key;
