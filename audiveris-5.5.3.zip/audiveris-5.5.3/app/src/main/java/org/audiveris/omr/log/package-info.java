/**
 * Package dedicated to logging.
 */
package org.audiveris.omr.log;
