/**
 * Package for the processing of beams.
 */
package org.audiveris.omr.sheet.beam;
