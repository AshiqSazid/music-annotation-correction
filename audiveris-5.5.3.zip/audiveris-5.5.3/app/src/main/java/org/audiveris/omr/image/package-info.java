/**
 * Package for image processing.
 */
package org.audiveris.omr.image;
