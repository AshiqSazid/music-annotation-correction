/**
 * Package for the processing of stems.
 */
package org.audiveris.omr.sheet.stem;
