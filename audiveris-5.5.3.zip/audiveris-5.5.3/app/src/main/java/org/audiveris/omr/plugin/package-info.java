/**
 * Package dedicated to handling of application plugins.
 */
package org.audiveris.omr.plugin;
