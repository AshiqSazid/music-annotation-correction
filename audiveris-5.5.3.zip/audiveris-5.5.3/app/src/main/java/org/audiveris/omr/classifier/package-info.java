/**
 * Package for various kinds of glyph descriptors and shape classifiers.
 */
package org.audiveris.omr.classifier;
