/**
 * Package for mathematical constructions.
 */
package org.audiveris.omr.math;
