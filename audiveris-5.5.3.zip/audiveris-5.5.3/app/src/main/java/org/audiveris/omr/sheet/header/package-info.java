/**
 * Package for the processing of Clefs, Key signatures and Time signatures in headers.
 */
package org.audiveris.omr.sheet.header;
