/**
 * Root package for the OMR application, providing application-wide entities.
 * All other packages are sub-packages of this one.
 */
package org.audiveris.omr;
