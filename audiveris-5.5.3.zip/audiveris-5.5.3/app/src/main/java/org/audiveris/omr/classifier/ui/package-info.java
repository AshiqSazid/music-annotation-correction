/**
 * Package for UI dedicated to classifier supervised training.
 */
package org.audiveris.omr.classifier.ui;
