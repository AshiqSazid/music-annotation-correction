/**
 * Package for handling dynamic assemblies of sections.
 */
package org.audiveris.omr.glyph.dynamic;
